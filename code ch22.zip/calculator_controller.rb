class CalculatorController < ApplicationController
  def index
    # render the default index.rhtml
  end  

  def calculate  
    begin
      @soap_request = render_to_string :partial => "soap"
      @calculation_result = call_calculation_service 
      @payments = @calculation_result["TRANSACTION"]["RESPONSE"]["PAYMENTSTREAM"]  
      @max_balance = @payments.max { |a,b| 
        a.PmtEndingBalance.to_f <=> b.PmtEndingBalance.to_f
      }.PmtEndingBalance.to_f  
    rescue Exception => e
      flash.now[:error] = "There was an error communicating with the service"
    end   
    if request.xhr?
      render :update  do |page|
        page.replace_html "payments", :partial => "calculate"
        page.call "replace_svg", page.send(:render, {:partial => "chart"})
      end      
    else 
      render :partial => "calculate", :layout => true
    end  
  end

  def chart
    render :partial => "chart", :content_type => "image/svg+xml"      
  end

  
private

  def call_calculation_service
    require "soap_extensions"
    endpoint_url = "http://compliancestudio.com/apr/1.0/service.asmx?WSDL"
    factory = SOAP::WSDLDriverFactory.new(endpoint_url)
    compliance_studio_service = factory.create_rpc_driver
    defined_elements = 
      compliance_studio_service.proxy.literal_mapping_registry.definedelements    
    defined_elements.delete(defined_elements.find_name("RequestCalculation"))
    param_name = XSD::QName.new("http://compliancestudio.com/apr/1.0", 
      "TransactionEnvelope")
    result = compliance_studio_service.RequestCalculation(param_name => 
      @soap_request)
    result["RequestCalculationResult"]    
  end  

end
