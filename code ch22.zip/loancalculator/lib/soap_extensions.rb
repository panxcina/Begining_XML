require 'soap/wsdlDriver'
require 'xsd/xmlparser/rexmlparser'

module SOAP::Mapping::Extensions
  def attribute_value(uri, name)
    __xmlattr[XSD::QName.new(uri, name)]
  end

  def method_missing(method_id, *arguments, &block)
    attr = attribute_value(nil, method_id.to_s)
    attr || super
  end  
end

SOAP::Mapping::Object.send( :include, SOAP::Mapping::Extensions )

