SELECT [PurchaseOrderID]
      ,[Status]
      ,[EmployeeID]
      ,[VendorID]
      ,[ShipMethodID]
      ,[OrderDate]
      ,[ShipDate]
      ,[SubTotal]
      ,[TaxAmt]
      ,[Freight]
      ,[TotalDue]
FROM [AdventureWorks].[Purchasing].[PurchaseOrderHeader]
WHERE [TotalDue] > 300000
FOR XML RAW('Order'), ROOT('Orders'), ELEMENTS XSINIL, XMLSCHEMA