SELECT [PurchaseOrderHeader].[PurchaseOrderID] [@PurchaseOrderID]
      ,[PurchaseOrderHeader].[Status] [@Status]
      ,[PurchaseOrderHeader].[EmployeeID] [@EmployeeID]
      ,[PurchaseOrderHeader].[VendorID] [@VendorID]
      ,[PurchaseOrderHeader].[ShipMethodID] [@ShipMethodID]
      ,[PurchaseOrderHeader].[SubTotal] [@SubTotal]
      ,[PurchaseOrderHeader].[TaxAmt] [@TaxAmt]
      ,[PurchaseOrderHeader].[Freight] [@Freight]
      ,[PurchaseOrderHeader].[TotalDue] [@TotalDue]
      ,[PurchaseOrderHeader].[OrderDate] [Dates/Order]
      ,[PurchaseOrderHeader].[ShipDate] [Dates/Ship]
      ,(
         SELECT [PurchaseOrderDetail].[OrderQty]
               ,[PurchaseOrderDetail].[ProductID]
               ,[PurchaseOrderDetail].[UnitPrice]      
         FROM [Purchasing].[PurchaseOrderDetail] PurchaseOrderDetail
         WHERE PurchaseOrderHeader.[PurchaseOrderID] = PurchaseOrderDetail.[PurchaseOrderID]
         ORDER BY PurchaseOrderDetail.[PurchaseOrderID]
         FOR XML PATH('OrderDetail'), TYPE
       ) [OrderDetails]
FROM [Purchasing].[PurchaseOrderHeader] PurchaseOrderHeader     
WHERE [PurchaseOrderHeader].[TotalDue] > 300000
FOR XML PATH('Order'), ROOT('Orders')