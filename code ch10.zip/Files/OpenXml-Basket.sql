DECLARE @BasketXml NVARCHAR(MAX)
DECLARE @BasketPointer INT
SET @BasketXml = '<basket customerId="12345">
                    <item productId="a123" quantity="1"/>
                    <item productId="b456" quantity="3"/>
                    <item productId="c789" quantity="2"/>
                   </basket>'
EXEC sp_xml_prepareDocument @BasketPointer OUTPUT, @BasketXml
 
DECLARE @BasicBasket TABLE
(
  ProductId NVARCHAR(20),
  Quantity INT
)

INSERT @BasicBasket
  SELECT productId ProductId,
         quantity Quantity
  FROM OPENXML (@BasketPointer, '/basket/item', 1)
  WITH
  (productId NVARCHAR(20),
   quantity INT)

EXEC sp_xml_removeDocument @BasketPointer

SELECT * FROM @BasicBasket 