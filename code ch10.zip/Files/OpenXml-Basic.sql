DECLARE @XmlData NVARCHAR(MAX)
DECLARE @XmlPointer INT
SET @XmlData = '<root><element>One</element><element>Two</element></root>'
EXEC sp_xml_preparedocument @XmlPointer OUTPUT, @XmlData

SELECT *
FROM OPENXML (@XmlPointer, '/root/element', 2)
      WITH (newName  NVARCHAR(100) '.')


EXEC sp_xml_removeDocument @XmlPointer