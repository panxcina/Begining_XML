CREATE XML SCHEMA COLLECTION EmployeesSchemaCollection AS
'<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema" targetNamespace="http://wiley.com/namespaces/Person" xmlns="http://wiley.com/namespaces/Person">
 <xsd:element name="Person">
  <xsd:complexType>
   <xsd:sequence>
    <xsd:element name="FirstName" />
    <xsd:element name="LastName" />
   </xsd:sequence>
  </xsd:complexType>
 </xsd:element>
</xsd:schema>'

SELECT xml_schema_namespace(N'dbo', N'EmployeesSchemaCollection')
