SELECT [POH].[PurchaseOrderID]
      ,[POH].[Status]
      ,[POH].[EmployeeID]
      ,[POH].[VendorID]
      ,[POH].[ShipMethodID]
      ,[POH].[OrderDate]
      ,[POH].[ShipDate]
      ,[POH].[SubTotal]
      ,[POH].[TaxAmt]
      ,[POH].[Freight]
      ,[POH].[TotalDue]
      ,[POD].[OrderQty]
      ,[POD].[ProductID]
      ,[POD].[UnitPrice]
FROM [Purchasing].[PurchaseOrderHeader] POH
     INNER JOIN  Purchasing.PurchaseOrderDetail POD
     ON POH.[PurchaseOrderID] = POD.[PurchaseOrderID]
WHERE [POH].[TotalDue] > 300000
FOR XML RAW('Order'), ROOT('Orders'), ELEMENTS XSINIL