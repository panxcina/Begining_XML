DECLARE @NewName NVARCHAR(100)
SET @NewName = N'Salt'
DECLARE @SQL NVARCHAR(MAX)
SET @SQL = 'UPDATE Docs SET XmlDoc.modify('' replace value of (/Person/LastName/text())[1] with "' + @NewName + '"'') WHERE DocId = 1'
SELECT * FROM Docs WHERE DocId = 1
PRINT(@SQL)
EXEC(@SQL)
SELECT * FROM Docs WHERE DocId = 1
