SELECT * FROM Docs WHERE DocId = 1
UPDATE Docs
SET XmlDoc.modify(' replace value of (/Person/LastName/text())[1] with "Salt"')
WHERE DocId = 1
SELECT * FROM Docs WHERE DocId = 1