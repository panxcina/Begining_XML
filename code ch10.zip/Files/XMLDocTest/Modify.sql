/*
CREATE TABLE dbo.Docs (
 DocID INTEGER IDENTITY PRIMARY KEY,
 XMLDoc XML
 )

CREATE FULLTEXT CATALOG ft ON DEFAULT
CREATE FULLTEXT INDEX ON dbo.Docs(XmlDoc) KEY INDEX PK__Docs__7C8480AE


TRUNCATE TABLE Docs

INSERT Docs
VALUES ('<Person><FirstName>Joe</FirstName>
<LastName>Fawcett</LastName></Person>'
)

INSERT Docs
VALUES ('<Person><FirstName>Eric</FirstName>
<LastName>van der Vlist</LastName></Person>'
)

INSERT Docs
VALUES ('<Person><FirstName>Jeff</FirstName>
<LastName>Rafter</LastName></Person>'
)

SELECT XmlDoc FROM Docs
*/

DECLARE @myDoc XML
SET @myDoc = '<Person><FirstName>Joe</FirstName><LastName>Fawcett</LastName></Person>'

SELECT @myDoc
SET @myDoc.modify('delete /Person/*[2]')
SELECT @myDoc

DECLARE @myDoc XML
SET @myDoc = '<Person><LastName>Fawcett</LastName></Person>'

SELECT @myDoc
SET @myDoc.modify(' insert <FirstName>Joe</FirstName> as first into /Person[1]')
SELECT @myDoc

DECLARE @myDoc XML
SET @myDoc = '<Person><LastName>Fawcett</LastName></Person>'

SELECT @myDoc
SET @myDoc.modify(' insert <FirstName>Joe</FirstName> before (/Person/LastName)[1]')
SELECT @myDoc

DECLARE @myDoc XML
SET @myDoc = '<Person><FirstName>Joe</FirstName><LastName>Fawcett</LastName></Person>'
SELECT @myDoc

SET @myDoc.modify(' replace value of (/Person/FirstName/text())[1] with "Gillian"')
SELECT @myDoc









