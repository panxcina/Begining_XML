DECLARE @NewName NVARCHAR(100)
SET @NewName = N'Salt'
SELECT * FROM Docs WHERE DocId = 1
UPDATE Docs
SET XmlDoc.modify(' replace value of (/Person/LastName/text())[1] with sql:variable("@NewName")')
WHERE DocId = 1
SELECT * FROM Docs WHERE DocId = 1
