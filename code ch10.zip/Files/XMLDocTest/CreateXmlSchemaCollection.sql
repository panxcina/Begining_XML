CREATE XML SCHEMA COLLECTION EmployeesSchemaCollection AS
'<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema" targetNamespace="http://www.XMML.com/SampleNamespacewiley.com/namespaces/Person" xmlns="http://www.XMML.com/SampleNamespacewiley.com/namespaces/Person">
 <xsd:element name="Person">
  <xsd:complexType>
   <xsd:sequence>
    <xsd:element name="FirstName" />
    <xsd:element name="LastName" />
   </xsd:sequence>
  </xsd:complexType>
 </xsd:element>
</xsd:schema>'
