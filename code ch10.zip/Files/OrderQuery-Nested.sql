SELECT [PurchaseOrderHeader].[PurchaseOrderID]
      ,[PurchaseOrderHeader].[Status]
      ,[PurchaseOrderHeader].[EmployeeID]
      ,[PurchaseOrderHeader].[VendorID]
      ,[PurchaseOrderHeader].[ShipMethodID]
      ,[PurchaseOrderHeader].[OrderDate]
      ,[PurchaseOrderHeader].[ShipDate]
      ,[PurchaseOrderHeader].[SubTotal]
      ,[PurchaseOrderHeader].[TaxAmt]
      ,[PurchaseOrderHeader].[Freight]
      ,[PurchaseOrderHeader].[TotalDue]
      ,[PurchaseOrderDetail].[OrderQty]
      ,[PurchaseOrderDetail].[ProductID]
      ,[PurchaseOrderDetail].[UnitPrice]
FROM [Purchasing].[PurchaseOrderHeader] PurchaseOrderHeader
     INNER JOIN  Purchasing.PurchaseOrderDetail PurchaseOrderDetail
     ON PurchaseOrderHeader.[PurchaseOrderID] = PurchaseOrderDetail.[PurchaseOrderID]
WHERE [PurchaseOrderHeader].[TotalDue] > 300000