drop database if exists myBlog;

create database myBlog DEFAULT CHARACTER SET 'utf8';

use myBlog;

drop table if exists entries;

create table entries (
	id int PRIMARY KEY,
	content LONGTEXT
);

insert into entries values (
	1,
	'<?xml version="1.0"?>
<item id="1">
  <title>Working on Beginning XML</title>
  <description>
    <p>
      <a href="http://www.wrox.com/WileyCDA/WroxTitle/productCd-0764570773.html">
        <img src="http://media.wiley.com/product_data/coverImage/73/07645707/0764570773.jpg"
          align="left"/>
      </a> I am currently working on the next edition of <a
        href="http://www.wrox.com/WileyCDA/WroxTitle/productCd-0764570773.html">WROX\'s excellent
        "Beginning XML".</a>
    </p>
    <p>It\'s the first time I am working on editing a book that I haven\'t written and I must say that
      I like it still better than I had expected when I have accepted WROX\'s offer.</p>
    <p>I knew that the book was solid and that I would be working with a team of very professional
      authors, but what I hadn\'t anticipated is how fun it can be to create a new version out of
      existing material. You have a lot of room to reorganize what you are editing and when the
      material is good, it\'s like creating your own stuff, except that 80% of the hard work is
      already done!</p>
  </description>
  <category>English</category>
  <category>XML</category>
  <category>Books/Livres</category>
  <pubDate>2006-11-13T17:32:01+01:00</pubDate>
  <comment-count>0</comment-count>
</item>
'); 

insert into entries values (
	2,
	'<?xml version="1.0"?>
<item id="2">
  <title>eXist: getting better with each release</title>
  <description>
    <p>There are two kind of software: those which get more complex and those which get easier to
      use with each new release...</p>
    <p>The first category makes me flee and after having played for a while with <a
        href="http://exist-db.org/">eXist</a> newest release ("<a
        href="http://prdownloads.sourceforge.net/exist/eXist-1.1.1-newcore-build4311.jar">eXist
        1.1.1-newcore</a>"), I am happy to report that the Open Source XML database definitely
      belongs to the first category!</p>
    <p>Exist now comes with a nifty installer and a couple of minutes after you\'ve got your
      download, your database is up and ready to be accessed through a number of different methods
      including a simple web application, WEBDAV, xml-rpc and their very handy REST interface.</p>
  </description>
  <category>English</category>
  <category>XML</category>
  <pubDate>2006-11-13T18:07:58+01:00</pubDate>
  <comment-count>0</comment-count>
</item>
');

select * from entries;

select count(*) from entries;

select id, substring(content, 1, 80) from entries;

select id, ExtractValue(content, '/item/title') as title FROM entries;

select id from entries where ExtractValue(content, '/item/title') = 
  'eXist: getting better with each release';

select id, ExtractValue(content, '/item/description') as title FROM entries;

select id, ExtractValue(content, '/item/description//text()') 
  as description FROM entries;

select id, ExtractValue(content, '/item/title') as title 
  from entries 
  where ExtractValue(content, '/item/category="Books/Livres"') = 1;

select id, ExtractValue(content, '//img') FROM entries;

select id, ExtractValue(content, '/item/title') as title 
  from entries 
  where ExtractValue(content, '//img') != '';

select id, ExtractValue(content, '/item/title') as title 
  from entries 
  where ExtractValue(content, 'count(//img)') > 0;

select id, ExtractValue(content, '/item/title') as title 
  from entries 
  where ExtractValue(content, 'count(//a[starts-with(@href,"http://www.wrox.com" )])') >0;

select id, ExtractValue(content, '/item/title') as title 
  from entries where ExtractValue(content, '//a/@href') 
  like '%http://www.wrox.com%';

exit

select id, ExtractValue(content, '/item/title') as title FROM entries;

update entries 
  set content = UpdateXml(content, 
    '/item/title', 
    '<title>eXist DB is getting much better with each release</title>') 
   where id=2;

select id, ExtractValue(content, '/item/title') as title FROM entries;
