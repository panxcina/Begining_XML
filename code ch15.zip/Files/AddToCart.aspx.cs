using System;
using System.Web;
using System.Xml;
using System.Xml.XPath;

public partial class AddToCart : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {
    XmlDocument soapDoc = new XmlDocument();
    string responseXml = string.Empty;
    string cartId = string.Empty;
    int quantity = 0;
    string itemId = string.Empty;
    try
    {
      soapDoc.Load(Request.InputStream);
    }
    catch (Exception ex)
    {
      responseXml = GetFailureXml("Sender",
                                  "rpc:ProcedureNotPresent",
                                  "Malformed request",
                                  1,
                                  "Unable to read SOAP request:" + ex.Message);
    }
    XmlNamespaceManager nsm = new XmlNamespaceManager(soapDoc.NameTable);
    nsm.AddNamespace("soap", "http://www.w3.org/2003/05/soap-envelope");
    nsm.AddNamespace("o", "http://www.wiley.com/soap/ordersystem");
    string xpath = "/soap:Envelope/soap:Body/o:AddToCart";
    XmlNode procedureNode = soapDoc.SelectSingleNode(xpath, nsm);
    XmlNode node = null;
    if (procedureNode == null)
    {
      responseXml = GetFailureXml("Sender",
                                  "rpc:ProcedureNotPresent",
                                  "Unable to find AddToCart element",
                                  2,
                                  "Unable to find AddToCart element");
    }
    else
    {
      xpath = "o:CartId";
      node = procedureNode.SelectSingleNode(xpath, nsm);
      if (node == null)
      {
        responseXml = GetFailureXml("Sender",
                                    "rpc:BadArguments",
                                    "Parameter not found",
                                    3,
                                    "Unable to find CartId");
      }
      else
      {
        cartId = node.InnerText;
        xpath = "o:Item/@ItemId";
        node = procedureNode.SelectSingleNode(xpath, nsm);
        if (node == null)
        {
          responseXml = GetFailureXml("Sender",
                                      "rpc:BadArguments",
                                      "Parameter not found",
                                      4,
                                      "Unable to find Quantity");
        }
        else
        {
          itemId = node.Value;
          xpath = "o:Item/o:Quantity";
          node = procedureNode.SelectSingleNode(xpath, nsm);
        }
        if (node == null)
        {
          responseXml = GetFailureXml("Sender",
                                      "rpc:BadArguments",
                                      "Parameter not found",
                                      5,
                                      "Unable to find ItemId");
        }
        else
        {
          quantity = int.Parse(node.InnerText);
        }
        SaveCart(cartId, quantity, itemId);
        responseXml = GetSuccessXml(cartId, quantity, itemId);
      }
    }
    soapDoc.LoadXml(responseXml);
    soapDoc.Save(Response.OutputStream);
  }

  private void SaveCart(string CartId, int Quantity, string ItemId)
  {
    //Save details to database etc.
  }

  private string GetSuccessXml(string CartId, int Quantity, string ItemId)
  {
    string responseXml = "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\">"
                       + "<soap:Body><o:AddToCartResponse "
                       + "xmlns:o=\"http://www.wiley.com/soap/ordersystem\">"
                       + "<o:CartId>{0}</o:CartId>"
                       + "<o:Status>OK</o:Status>"
                       + "<o:Quantity>{1}</o:Quantity>"
                       + "<o:ItemId>{2}</o:ItemId>"
                       + "</o:AddToCartResponse>"
                       + "</soap:Body></soap:Envelope>";
    return string.Format(responseXml, CartId, Quantity, ItemId);
  }

  private string GetFailureXml(string faultCode, string subValue, string reason, int errorCode, string message)
  {
    string responseXml = "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" "
                       + "xmlns:rpc=\"http://www.w3.org/2003/05/soap-rpc\">"
                       + "<soap:Body><soap:Fault><soap:Code>"
                       + "<soap:Value>soap:{0}</soap:Value>"
                       + "<soap:Subcode><soap:Value>{1}</soap:Value>"
                       + "</soap:Subcode></soap:Code><soap:Reason>"
                       + "<soap:Text>{2}</soap:Text></soap:Reason>"
                       + "<soap:Detail><o:OrderFaultInfo "
                       + "xmlns:o=\"http://www.wiley.com/soap/ordersystem\">"
                       + "<o:ErrorCode>{3}</o:ErrorCode>"
                       + "<o:Message>{4}</o:Message></o:OrderFaultInfo>"
                       + "</soap:Detail></soap:Fault></soap:Body></soap:Envelope>";
    return string.Format(responseXml, faultCode, subValue, reason, errorCode, message);
  }
}
