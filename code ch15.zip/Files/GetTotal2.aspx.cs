using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;

public partial class _Default : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {
    string clientXml = string.Empty;
    try
    {
      double unitPrice = Convert.ToDouble(Request.QueryString["unitPrice"]);
      int quantity = Convert.ToInt16(Request.QueryString["quantity"]);      
      double discount = GetQuantityDiscount(quantity);
      double basicTotal = GetBasicTotal(unitPrice, quantity);
      double finalTotal = basicTotal * (1 - discount);
      clientXml = GetSuccessXml(finalTotal, discount * 100);
    }
    catch (Exception ex)
    {
      clientXml = GetErrorXml(ex);
    }
    XmlDocument doc = new XmlDocument();
    doc.LoadXml(clientXml);
    doc.Save(Response.OutputStream);
  }

  private double GetBasicTotal(double unitPrice, int quantity)
  {
    return unitPrice * quantity;
  }

  private double GetQuantityDiscount(int quantity)
  {
    if (quantity < 6) return 0;
    if (quantity < 11) return 0.05;
    if (quantity < 51) return 0.1;
    return 0.2;
  }

  private string GetSuccessXml(double totalPrice, double discount)
  {
    string clientXml = "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\"><soap:Body>"
                     + "<GetTotalResponse "
                     + "xmlns=\"http://www.wiley.com/soap/ordersystem\"><Discount>{0}</Discount>"
                     + "<TotalPrice>{1}</TotalPrice>"
                     + "</GetTotalResponse></soap:Body></soap:Envelope>";
    return string.Format(clientXml, Convert.ToString(discount), Convert.ToString(totalPrice));
  }


  private string GetErrorXml(Exception ex)
  {
    string clientXml = "<Error><Reason>{0}</Reason></Error>";
    return string.Format(clientXml, ex.Message);
  }
}
