function lTrim()
{
  return this.replace(/^\s*/g, "");
}

function rTrim()
{
  return this.replace(/\s*$/g, "");
}

function trim()
{
  return this.lTrim().rTrim();
}

String.prototype.lTrim = lTrim;
String.prototype.rTrim = rTrim;
String.prototype.trim = trim;