using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.IO;
using System.Xml.Serialization;
using System.Xml;
using com.compliancestudio;

public enum ProgramType
{
    Fixed,
    Hybrid,
    InterestOnlyOption
}


[WebService(Namespace = "http://localhost/ProxyCalculationService")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService
{
    public Service () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public XmlNode CalculatePassThrough(string TransactionEnvelope) {
        XmlDocument request = new XmlDocument();
        request.LoadXml(TransactionEnvelope);
        com.compliancestudio.Service cs = new com.compliancestudio.Service();
        return cs.RequestCalculation(request.DocumentElement);        
    }

    [WebMethod]
    public XmlNode Calculate(PaymentStreamRequestType PaymentRequestType,
      ProgramType LoanProgram, double TotalAPRFeesAmount, double IndexValue,
      double MarginValue, double OriginalLoanAmount,
      double DisclosedTotalSalesPriceAmount, double PropertyAppraisedValueAmount,
      double NoteRatePercent, int LoanOriginalMaturityTermMonths,
      DateTime ApplicationSignedDate, DateTime LoanEstimatedClosingDate,
      DateTime ScheduledFirstPaymentDate, int EstimatedPrepaidDays)
    {

        TRANSACTION aprTransaction = new TRANSACTION();
        REQUEST aprRequest = new REQUEST();
        REQUESTOPTIONS aprRequestOptions = new REQUESTOPTIONS();
        DATA aprRequestOptionsData = new DATA();
        APRREQUEST aprAprRequest = new APRREQUEST();
        LOANDATA aprLoanData = new LOANDATA();
        TERMS aprTerms = new TERMS();

        aprTransaction.REQUEST = aprRequest;
        aprTransaction.REQUEST.REQUESTOPTIONS = aprRequestOptions;
        aprTransaction.REQUEST.REQUESTOPTIONS.DATA = aprRequestOptionsData;
        aprTransaction.REQUEST.APRREQUEST = new APRREQUEST[1];
        aprTransaction.REQUEST.APRREQUEST[0] = aprAprRequest;
        aprTransaction.REQUEST.LOANDATA = aprLoanData;
        aprTransaction.REQUEST.LOANDATA.TERMS = aprTerms;

        aprRequestOptions.PaymentStreamAndApr = true;
        aprRequestOptions.ReverseApr = false;
        aprRequestOptions.ManualPaymentStream = false;
        aprRequestOptions.AdditionalPrincipal = false;
        aprRequestOptionsData.PaymentStreamRequestType = PaymentRequestType;
        aprRequestOptionsData.AllowOddLastPayment = true;
        aprRequestOptionsData.DaysPerYear = DaysPerYear.Item360;
        aprRequestOptionsData.ConstructionTILType = ConstructionTILType.Seperate;
        aprRequestOptionsData.AprIterations = 1;
        aprRequestOptionsData.FeeIterations = 0;

        switch (LoanProgram)
        {
            case ProgramType.Fixed:
                aprTerms.ProgramName = "FIXED 360/360";
                break;
            case ProgramType.Hybrid:
                aprTerms.ProgramName = "FIXED 50 30 10";
                break;
            case ProgramType.InterestOnlyOption:
                aprTerms.ProgramName = "GMAC IO Option Neg ARM";
                break;
        }

        aprTerms.LoanOriginationSystemLoanIdentifier = "Beginning XML Calculator";
        aprTerms.OriginalLoanAmount = OriginalLoanAmount;
        aprTerms.DisclosedTotalSalesPriceAmount = DisclosedTotalSalesPriceAmount;
        aprTerms.PropertyAppraisedValueAmount = PropertyAppraisedValueAmount;
        aprTerms.NoteRatePercent = NoteRatePercent;
        aprTerms.InitialPaymentRatePercent = NoteRatePercent;
        aprTerms.LoanOriginalMaturityTermMonths = LoanOriginalMaturityTermMonths;
        aprTerms.ApplicationSignedDate = ApplicationSignedDate;
        aprTerms.LoanEstimatedClosingDate = LoanEstimatedClosingDate;
        aprTerms.ScheduledFirstPaymentDate = ScheduledFirstPaymentDate;
        aprTerms.EstimatedPrepaidDays = EstimatedPrepaidDays;
        aprAprRequest.TotalAPRFeesAmount = TotalAPRFeesAmount;

        aprRequestOptions.PaymentStreamAndAprSpecified = true;
        aprRequestOptions.ReverseAprSpecified = true;
        aprRequestOptions.ManualPaymentStreamSpecified = true;
        aprRequestOptions.AdditionalPrincipalSpecified = true;
        aprRequestOptionsData.PaymentStreamRequestTypeSpecified = true;
        aprRequestOptionsData.AllowOddLastPaymentSpecified = true;
        aprRequestOptionsData.DaysPerYearSpecified = true;
        aprRequestOptionsData.ConstructionTILTypeSpecified = true;
        aprRequestOptionsData.AprIterationsSpecified = true;
        aprRequestOptionsData.FeeIterationsSpecified = true;
        aprAprRequest.TotalAPRFeesAmountSpecified = true;
        aprTerms.OriginalLoanAmountSpecified = true;
        aprTerms.DisclosedTotalSalesPriceAmountSpecified = true;
        aprTerms.PropertyAppraisedValueAmountSpecified = true;
        aprTerms.NoteRatePercentSpecified = true;
        aprTerms.InitialPaymentRatePercentSpecified = true;
        aprTerms.LoanOriginalMaturityTermMonthsSpecified = true;
        aprTerms.ApplicationSignedDateSpecified = true;
        aprTerms.LoanEstimatedClosingDateSpecified = true;
        aprTerms.ScheduledFirstPaymentDateSpecified = true;
        aprTerms.EstimatedPrepaidDaysSpecified = true;

        if (IndexValue != 0 && MarginValue != 0)
        {
            INDEXVALUES aprIndexValues = new INDEXVALUES();
            MARGINVALUES aprMarginValues = new MARGINVALUES();

            aprTransaction.REQUEST.INDEXVALUES = new INDEXVALUES[1];
            aprTransaction.REQUEST.INDEXVALUES[0] = aprIndexValues;
            aprTransaction.REQUEST.MARGINVALUES = new MARGINVALUES[1];
            aprTransaction.REQUEST.MARGINVALUES[0] = aprMarginValues;

            aprIndexValues.IndexValue = IndexValue;
            aprMarginValues.MarginValue = MarginValue;
            aprIndexValues.IndexMonths = LoanOriginalMaturityTermMonths;
            aprMarginValues.MarginMonths = LoanOriginalMaturityTermMonths;

            aprIndexValues.IndexValueSpecified = true;
            aprIndexValues.IndexMonthsSpecified = true;
            aprMarginValues.MarginValueSpecified = true;
            aprMarginValues.MarginMonthsSpecified = true;
        }

        MemoryStream ms = new MemoryStream();
        XmlDocument request = new XmlDocument();
        XmlSerializer serializer = new XmlSerializer(aprTransaction.GetType());
        serializer.Serialize(ms, aprTransaction);
        ms.Seek(0, SeekOrigin.Begin);
        request.Load(ms);
        com.compliancestudio.Service cs = new com.compliancestudio.Service();
        return cs.RequestCalculation(request.DocumentElement);       
    }

    
}
