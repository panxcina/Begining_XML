var submitting = false;

function showProgress() {
  try {
    submitting = true;
    var working = document.getElementById("working");
    working.style.display = "inline";
    var calc = document.getElementById("calculate_button");
    calc.disabled = true;
  } catch(e) {
    // do nothing
  }
}

function hideProgress() {
  try {
    submitting = false;
    var working = document.getElementById("working");
    working.style.display = "none";
    var calc = document.getElementById("calculate_button");
    calc.disabled = false;
  } catch(e) {
    // do nothing
  }
}

function submitLoanInformation() {
  if (submitting) return;
  showProgress();
  try {
   if (xmlhttp) {
     var request = ''+
'<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'+
'<soap:Body>'+
'<Calculate xmlns="http://localhost/ProxyCalculationService">'+
'<PaymentRequestType>Long</PaymentRequestType>'+
'<LoanProgram>' + getSelectValue('ProgramName') + '</LoanProgram>'+
'<TotalAPRFeesAmount>' + getFloatValue('TotalAPRFeesAmount') + '</TotalAPRFeesAmount>'+
'<IndexValue>' + getFloatValue('IndexValue') + '</IndexValue>'+
'<MarginValue>' + getFloatValue('MarginValue') + '</MarginValue>'+
'<OriginalLoanAmount>' + getFloatValue('OriginalLoanAmount') + '</OriginalLoanAmount>'+
'<DisclosedTotalSalesPriceAmount>' + getFloatValue('DisclosedTotalSalesPriceAmount') + '</DisclosedTotalSalesPriceAmount>'+
'<PropertyAppraisedValueAmount>' + getFloatValue('PropertyAppraisedValueAmount') + '</PropertyAppraisedValueAmount>'+
'<NoteRatePercent>' + getFloatValue('NoteRatePercent') + '</NoteRatePercent>'+
'<LoanOriginalMaturityTermMonths>' + getFloatValue('LoanOriginalMaturityTermMonths') + '</LoanOriginalMaturityTermMonths>'+
'<ApplicationSignedDate>' + getDateValue() + '</ApplicationSignedDate>'+
'<LoanEstimatedClosingDate>' + getDateValue() + '</LoanEstimatedClosingDate>'+
'<ScheduledFirstPaymentDate>' + getDateValue() + '</ScheduledFirstPaymentDate>'+
'<EstimatedPrepaidDays>' + getPrepaidDays() + '</EstimatedPrepaidDays>'+
'</Calculate>'+
'</soap:Body>'+
'</soap:Envelope>'+
     '';
     xmlhttp.open("POST", "/ProxyCalculationService/Service.asmx", true);
     xmlhttp.onreadystatechange=function() {
       if (xmlhttp.readyState==4) {
         receiveLoanInformation(xmlhttp.responseXML);
       }
     }
     xmlhttp.setRequestHeader("SOAPAction", "http://localhost/ProxyCalculationService/Calculate");
     xmlhttp.setRequestHeader("Content-Type", "text/xml");
     xmlhttp.setRequestHeader("Content-Length", request.length);
     xmlhttp.send(request);
   }
  } catch(ex) {
    hideProgress();
    alert(ex.toString());
  }
}

function getSelectValue(id) {
   var obj = document.getElementById(id);
   return (obj.selectedIndex > -1 ? obj.options[obj.selectedIndex].value : "");
}

function getFloatValue(id) {
   var obj = document.getElementById(id);
   return (obj ? parseFloat(obj.value) : 0);
}

function getDateValue() {
  var d = new Date();
  if (d.getDate() > 15)
    d.setMonth(d.getMonth()+1);
  return d.getFullYear() + "-" + (d.getMonth()+1) + "-15";
}

function getPrepaidDays() {
  var d = new Date();
  if (d.getDate() > 15)
    d.setMonth(d.getMonth()+1);
  d.setDate(0);
  return d.getDate()-15;
}

function receiveLoanInformation(responseXML) {
  try {
    if (responseXML.documentElement == null) return;
    var payments = responseXML.documentElement.getElementsByTagName("PAYMENTSTREAM");
    var totalPayments = payments.length;
    var payment = 0;
    var balance = 0;
    var tableHTML = "" +
      "<table border='0' cellpadding='0' cellspacing='0'>" +
      "  <tr>" +
      "    <th>Payment Date</th>" +
      "    <th>Payment Amount</th>" +
      "    <th>Remaining Balance</th>" +
      "  </tr>";
    for (var i = 0; i < totalPayments; i++) {
      payment = parseFloat(payments[i].getAttribute("PmtTotal"));
      balance = parseFloat(payments[i].getAttribute("PmtEndingBalance"));
      tableHTML += ""+
        "<tr " + ((i % 2 == 0) ? "class='even_row'>" : "class='odd_row'>") +
        "<td>" + payments[i].getAttribute("PmtDate") + "</td>" +
        "<td class='numeric_cell'>" + formatDollar(payment) + "</td>" +
        "<td class='numeric_cell'>" + formatDollar(balance) + "</td>" +
        "</tr>";
    }
    tableHTML += "</table>";
    var tableContainer = document.getElementById("payments_table");
    tableContainer.innerHTML = tableHTML;
    drawChart(payments);
  } finally {
    hideProgress();
  }
}

function formatDollar(value) {
  value *= 100;
  value = Math.round(value);
  value /= 100;
  var res = "$" + value;
  if (res.indexOf(".") == -1) {
    res += ".00";
  } else {
    while (res.indexOf(".") > res.length-2) res += "0";
  }
  return res;
}

function drawChart(payments) {
  if (svgWindow == null) return;
  var left = 10;
  var top = 10;
  var width = 500;
  var height = 200;

  var totalPayments = payments.length;
  var maxBalance = -1;
  var balance = 0;
  for (var i = 0; i < totalPayments; i++) {
    balance = parseFloat(payments[i].getAttribute("PmtEndingBalance"));
    if (maxBalance == -1 || maxBalance < balance) maxBalance = balance;
  }

  var balance100Percent = svgWindow.document.getElementById("balance100Percent");
  var balance75Percent = svgWindow.document.getElementById("balance75Percent");
  var balance50Percent = svgWindow.document.getElementById("balance50Percent");
  var balance25Percent = svgWindow.document.getElementById("balance25Percent");
  balance100Percent.firstChild.nodeValue = formatDollar(maxBalance);
  balance75Percent.firstChild.nodeValue = formatDollar(0.75 * maxBalance);
  balance50Percent.firstChild.nodeValue = formatDollar(0.50 * maxBalance);
  balance25Percent.firstChild.nodeValue = formatDollar(0.25 * maxBalance);

  var paymentWidth = (width / totalPayments);
  var balanceHeight = (height / maxBalance);
  var balanceData = "M " + left + "," + (top+height);
  for (var i = 0; i < totalPayments; i++) {
    balanceData += "L" + (left+(i*paymentWidth)) + "," +
      ((top+height) - (balanceHeight*parseFloat(payments[i].getAttribute("PmtEndingBalance"))));
  }
  balanceData += " L" + (left+width) + "," + (top+height) + " z";
  var balancePath = svgWindow.document.getElementById("balance");
  balancePath.setAttribute("d", balanceData);

  var labels = svgWindow.document.getElementById("date_labels");
  while (labels.hasChildNodes()) {
    labels.removeChild(labels.firstChild);
  }
  for (var i = 1; i < totalPayments; i++) {
    if (i % 12 != 0) continue;
    var label = svgWindow.document.createElementNS("http://www.w3.org/2000/svg", "text");
    label.appendChild(svgWindow.document.createTextNode(payments[i].getAttribute("PmtDate")));
    label.setAttribute("text-anchor", "end");
    label.setAttribute("transform", "translate(" + (20+(i*paymentWidth))+ ", " + (20+height) + "), rotate(-45) ");
    labels.appendChild(label);
  }
}
