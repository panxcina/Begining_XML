var submitting = false;

function showProgress() {
  try {
    submitting = true;
    var working = document.getElementById("working");
    working.style.display = "inline";
    var calc = document.getElementById("calculate_button");
    calc.disabled = true;
  } catch(e) {
    // do nothing
  }
}

function hideProgress() {
  try {
    submitting = false;
    var working = document.getElementById("working");
    working.style.display = "none";
    var calc = document.getElementById("calculate_button");
    calc.disabled = false;
  } catch(e) {
    // do nothing
  }
}

function submitLoanInformation() {
  if (submitting) return;
  showProgress();
  try {
   if (xmlhttp) {
     var request = ''+
'<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'+
'<soap:Body>'+
'<Calculate xmlns="http://localhost/ProxyCalculationService">'+
'<PaymentRequestType>Long</PaymentRequestType>'+
'<LoanProgram>' + getSelectValue('ProgramName') + '</LoanProgram>'+
'<TotalAPRFeesAmount>' + getFloatValue('TotalAPRFeesAmount') + '</TotalAPRFeesAmount>'+
'<IndexValue>' + getFloatValue('IndexValue') + '</IndexValue>'+
'<MarginValue>' + getFloatValue('MarginValue') + '</MarginValue>'+
'<OriginalLoanAmount>' + getFloatValue('OriginalLoanAmount') + '</OriginalLoanAmount>'+
'<DisclosedTotalSalesPriceAmount>' + getFloatValue('DisclosedTotalSalesPriceAmount') + '</DisclosedTotalSalesPriceAmount>'+
'<PropertyAppraisedValueAmount>' + getFloatValue('PropertyAppraisedValueAmount') + '</PropertyAppraisedValueAmount>'+
'<NoteRatePercent>' + getFloatValue('NoteRatePercent') + '</NoteRatePercent>'+
'<LoanOriginalMaturityTermMonths>' + getFloatValue('LoanOriginalMaturityTermMonths') + '</LoanOriginalMaturityTermMonths>'+
'<ApplicationSignedDate>' + getDateValue() + '</ApplicationSignedDate>'+
'<LoanEstimatedClosingDate>' + getDateValue() + '</LoanEstimatedClosingDate>'+
'<ScheduledFirstPaymentDate>' + getDateValue() + '</ScheduledFirstPaymentDate>'+
'<EstimatedPrepaidDays>' + getPrepaidDays() + '</EstimatedPrepaidDays>'+
'</Calculate>'+
'</soap:Body>'+
'</soap:Envelope>'+
     '';
     xmlhttp.open("POST", "/ProxyCalculationService/Service.asmx", true);
     xmlhttp.onreadystatechange=function() {
       if (xmlhttp.readyState==4) {
         receiveLoanInformation(xmlhttp.responseXML);
       }
     }
     xmlhttp.setRequestHeader("SOAPAction", "http://localhost/ProxyCalculationService/Calculate");
     xmlhttp.setRequestHeader("Content-Type", "text/xml");
     xmlhttp.setRequestHeader("Content-Length", request.length);
     xmlhttp.send(request);
   }
  } catch(ex) {
    hideProgress();
    alert(ex.toString());
  }
}

function getSelectValue(id) {
   var obj = document.getElementById(id);
   return (obj.selectedIndex > -1 ? obj.options[obj.selectedIndex].value : "");
}

function getFloatValue(id) {
   var obj = document.getElementById(id);
   return (obj ? parseFloat(obj.value) : 0);
}

function getDateValue() {
  var d = new Date();
  if (d.getDate() > 15)
    d.setMonth(d.getMonth()+1);
  return d.getFullYear() + "-" + (d.getMonth()+1) + "-15";
}

function getPrepaidDays() {
  var d = new Date();
  if (d.getDate() > 15)
    d.setMonth(d.getMonth()+1);
  d.setDate(0);
  return d.getDate()-15;
}

function receiveLoanInformation(responseXML) {
  try {
    if (responseXML.documentElement == null) return;
    var payments = responseXML.documentElement.getElementsByTagName("PAYMENTSTREAM");
    var totalPayments = payments.length;
    var payment = 0;
    var balance = 0;
    var tableHTML = "" +
      "<table border='0' cellpadding='0' cellspacing='0'>" +
      "  <tr>" +
      "    <th>Payment Date</th>" +
      "    <th>Payment Amount</th>" +
      "    <th>Remaining Balance</th>" +
      "  </tr>";
    for (var i = 0; i < totalPayments; i++) {
      payment = parseFloat(payments[i].getAttribute("PmtTotal"));
      balance = parseFloat(payments[i].getAttribute("PmtEndingBalance"));
      tableHTML += ""+
        "<tr " + ((i % 2 == 0) ? "class='even_row'>" : "class='odd_row'>") +
        "<td>" + payments[i].getAttribute("PmtDate") + "</td>" +
        "<td class='numeric_cell'>" + formatDollar(payment) + "</td>" +
        "<td class='numeric_cell'>" + formatDollar(balance) + "</td>" +
        "</tr>";
    }
    tableHTML += "</table>";
    var tableContainer = document.getElementById("payments_table");
    tableContainer.innerHTML = tableHTML;
  } finally {
    hideProgress();
  }
}

function formatDollar(value) {
  value *= 100;
  value = Math.round(value);
  value /= 100;
  var res = "$" + value;
  if (res.indexOf(".") == -1) {
    res += ".00";
  } else {
    while (res.indexOf(".") > res.length-2) res += "0";
  }
  return res;
}


