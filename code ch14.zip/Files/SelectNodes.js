if( document.implementation.hasFeature("XPath", "3.0") )
{
  XMLDocument.prototype.selectNodes = function(cXPathString, xNode)
									 {
									  if( !xNode )
									  {
										xNode = this;
									  }
										
									  var defaultNS = this.defaultNS;

									  var aItems = this.evaluate(cXPathString, xNode,{
									   normalResolver:
										this.createNSResolver(this.documentElement),
											lookupNamespaceURI : function (prefix) {
											   switch (prefix) {
												 case "dflt":
													return defaultNS;
												 default:
													return this.normalResolver.lookupNamespaceURI(prefix);
											   }
											}
										  },XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null);

									  var aResult = [];
									  for( var i = 0; i < aItems.snapshotLength; i++){
											   aResult[i] =  aItems.snapshotItem(i);
									  }
									  return aResult;
									 }

 Element.prototype.selectNodes = function(cXPathString){
  if(this.ownerDocument.selectNodes){
   return this.ownerDocument.selectNodes(cXPathString, this);
  }else{
   throw "For XML Elements Only";
  }
 }

 /* set the SelectionNamespaces property the same for NN or IE: */
 XMLDocument.prototype.setProperty = function(p,v){
  if(p=="SelectionNamespaces" && v.indexOf("xmlns:dflt")==0){
   this.defaultNS = v.replace(/^.*=\'(.+)\'/,"$1");
  }
 }

 XMLDocument.prototype.defaultNS;

}