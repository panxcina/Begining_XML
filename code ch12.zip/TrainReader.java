import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

public class TrainReader extends DefaultHandler
{
  private boolean isColor;
  private String trainCarType = "";
  private StringBuffer trainCarColor = new StringBuffer();
  private Locator trainLocator = null;
  public static void main(String[] args)
    throws Exception
  {
    System.out.println("Running train reader...");
    TrainReader readerObj = new TrainReader();
    readerObj.read(args[0]);
  }

  public void read(String fileName)
    throws Exception
  {
    XMLReader reader =
      XMLReaderFactory.createXMLReader("org.apache.xerces.parsers.SAXParser");
    reader.setContentHandler(this);
    reader.setErrorHandler(this);
    try
    {
      reader.setFeature("http://xml.org/sax/features/validation", true);
    }
    catch (SAXException e)
    {
      System.err.println("Cannot activate validation");
    }
    try
    {
      reader.parse(fileName);
    }
    catch (SAXException e)
    {
      System.out.println("Parsing stopped : " + e.getMessage());
    }
  }

  public void startDocument()
    throws SAXException
  {
    System.out.println("Start of the train");
  }


  public void endDocument()
    throws SAXException
  {
    System.out.println("End of the train");
  }
  
  public void startElement(String uri, String localName, String qName,
    Attributes atts) throws SAXException
  {
    if ("car".equals(localName)) {
      if (atts != null) {
        trainCarType = atts.getValue("type");
      }
    }

    if ("color".equals(localName)) {
      trainCarColor.setLength(0);
      isColor = true;
    } else {
      isColor = false;
    }
  }

  public void characters(char[] ch, int start, int len)
    throws SAXException
  {
    if (isColor)
    {
      trainCarColor.append(ch, start, len);
    }
  }
  
  public void endElement(String uri, String localName, String qName)
    throws SAXException
  {
    if (isColor) {
      System.out.println("The color of the " + trainCarType + " car is " +
        trainCarColor.toString());
      isColor = false;
      if (("Caboose".equals(trainCarType)) &&
          (!"Red".equals(trainCarColor.toString()))) {
        if (trainLocator != null)
          throw new SAXException("The caboose is not red at line " +
            trainLocator.getLineNumber() + ", column " +
            trainLocator.getColumnNumber() );
        else
          throw new SAXException("The caboose is not red!");
      }
    }
  }
  
  public void setDocumentLocator(Locator locator)
  {
    trainLocator = locator;
  }
  
  public void warning (SAXParseException exception)
    throws SAXException {
    System.err.println("[Warning] " +
      exception.getMessage() + " at line " +
      exception.getLineNumber() + ", column " +
      exception.getColumnNumber() );
  }

  public void error (SAXParseException exception)
    throws SAXException {
    System.err.println("[Error] " +
      exception.getMessage() + " at line " +
      exception.getLineNumber() + ", column " +
      exception.getColumnNumber() );
  }

  public void fatalError (SAXParseException exception)
    throws SAXException {
    System.err.println("[Fatal Error] " +
      exception.getMessage() + " at line " +
      exception.getLineNumber() + ", column " +
      exception.getColumnNumber() );
    throw exception;
  }


}
