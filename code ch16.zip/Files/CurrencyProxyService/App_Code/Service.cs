using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

[WebService(Namespace = "http://www.wrox.com/webservices/CurrencyProxyService")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class Service : System.Web.Services.WebService
{
    [WebMethod(Description = "Accepts two currency codes and returns the currency exchange rate as a double.")]
    public double GetRate(string currencyFrom, string currencyTo)
    {
      webservicex.CurrencyConvertor exchange = new webservicex.CurrencyConvertor();
      webservicex.Currency from = (webservicex.Currency)Enum.Parse(typeof(webservicex.Currency), currencyFrom);
      webservicex.Currency to = (webservicex.Currency)Enum.Parse(typeof(webservicex.Currency), currencyTo);
      double rate = exchange.ConversionRate(from, to);
      return rate;
    }    
}
