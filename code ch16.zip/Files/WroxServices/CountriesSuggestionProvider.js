﻿  function SuggestionProvider(serviceUrl)
  {
    this.httpRequest = zXmlHttp.createRequest();
    this.serviceUrl = serviceUrl;
  }

  SuggestionProvider.prototype.fetchSuggestions = function (autoSuggestControl, show)
  {
    var request = this.httpRequest;
    if (request.readyState != 0)
    {
      request.abort();
    }
    var sQueryString = "?countryText=" + encodeURIComponent(autoSuggestControl.actualText);
    var sUrl = this.serviceUrl + sQueryString;
    request.onreadystatechange = function ()
    {
      if (request.readyState == 4)
      {
        var oResultsXml = request.responseXML;
        var oNamespaceMapper = {wrox: "http://www.wrox.com/webservices/GetCountries"};
        var sXPath = "/*/*/*/wrox:countries/wrox:country";
        var colCountries = zXPath.selectNodes(oResultsXml.documentElement, sXPath, oNamespaceMapper);
        var arrCountries = new Array();
        for (var i = 0; i < colCountries.length; i++)
        {
          arrCountries.push(colCountries[i].firstChild.nodeValue);
        }
        autoSuggestControl.suggest(arrCountries, show);
      }
    }
    request.open("GET", sUrl, true);
    request.send(null);
  }