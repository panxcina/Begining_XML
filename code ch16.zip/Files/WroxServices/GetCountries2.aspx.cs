using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Xml;
using System.Xml.Xsl;
using System.Web.Caching;

public partial class _Default : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {
    XmlDocument countriesXml = new XmlDocument();
    if (Cache["countriesXml"] == null)
    {
      string xmlPath = Server.MapPath("countries.xml");
      countriesXml.Load(xmlPath);
      Cache.Insert("countriesXml", countriesXml, new CacheDependency(xmlPath));
    }
    else
    {
      countriesXml = (XmlDocument)Cache["countriesXml"];
    }
    XslCompiledTransform countriesXslt = new XslCompiledTransform();
        if (Cache["countries2Xslt"] == null)
    {
      string xsltPath = Server.MapPath("countries2.xslt");
      countriesXslt.Load(xsltPath);
      Cache.Insert("countries2Xslt", countriesXslt, new CacheDependency(xsltPath));
    }
    else
    {
      countriesXslt = (XslCompiledTransform)Cache["countries2Xslt"];
    }
    try
    {
      string countryText = Request.QueryString["countryText"];
      XsltArgumentList args = new XsltArgumentList();
      args.AddParam("countryText", "", countryText);
      countriesXslt.Transform(countriesXml, args, Response.OutputStream);
    }
    catch (Exception ex)
    {
      SendError(ex);
    }
  }

  private void SendError(Exception ex)
  {
    string errorString = "[];";
    Response.Write(errorString);
  }
}
