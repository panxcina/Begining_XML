﻿function AutoSuggestControl(textbox, provider)
{
  this.textbox = textbox;
  this.provider = provider;
  this.suggestionsBox = null;
  this.currentSuggestionIndex = -1;
  this.actualText = textbox.value;
  this.timeoutId = null;
  this.defaultTimeout = 200;
  this.init();
}



AutoSuggestControl.prototype.selectTextRange = function(start, end)
{
  if (this.textbox.createTextRange)
  {
    var oRange = this.textbox.createTextRange();
    oRange.moveStart("character", start);
    oRange.moveEnd("character", end - this.textbox.value.length);
    oRange.select();
  }
  else if (this.textbox.setSelectionRange)
       {
         this.textbox.setSelectionRange(start, end);
       }
  this.textbox.focus();
}

AutoSuggestControl.prototype.showFullSuggestion = function (suggestion)
{
  if (this.textbox.createTextRange || this.textbox.setSelectionRange)
  {
    var iCharCount = this.textbox.value.length;
    this.textbox.value = suggestion;
    this.selectTextRange(iCharCount, suggestion.length);
  }
}

AutoSuggestControl.prototype.suggest = function (suggestions, show)
{
  this.currentSuggestionIndex = -1;
  if (suggestions.length > 0)
  {
    if (show)
    {
      this.showFullSuggestion(suggestions[0]);
    }
    this.showSuggestions(suggestions);
  }
  else
  {
    this.hideSuggestionsBox();
  }
}

AutoSuggestControl.prototype.handleKeyUp = function (e)
{
  var me = this;
  clearTimeout(this.timeoutId);
  this.actualText = this.textbox.value;
  var iCode = e.keyCode;
  if (!(iCode < 8
     || (iCode > 8 && iCode < 32)
     || (iCode > 32 && iCode < 46)
     || (iCode > 111 && iCode < 124)))
  {
    if (iCode == 8 || iCode == 46)
    {
      this.timeoutId = setTimeout( function () {
                   me.provider.fetchSuggestions(me, false);}, this.defaultTimeout);
    }
    else
    {
      this.timeoutId = setTimeout( function () {
                   me.provider.fetchSuggestions(me, true);}, this.defaultTimeout);
    }
  }
}


AutoSuggestControl.prototype.init = function()
{
  var me = this;
  this.textbox.onkeyup = function (e)
  {
    me.handleKeyUp(e || window.event);
  }
  this.textbox.onkeydown = function (e)
  {
    me.handleKeyDown(e || window.event);
  }
  this.textbox.onblur = function ()
  {
    me.hideSuggestionsBox();
  }
  this.createSuggestionsBox();
}

AutoSuggestControl.prototype.hideSuggestionsBox = function ()
{
  this.suggestionsBox.style.visibility = "hidden";
}

AutoSuggestControl.prototype.highlightSuggestion = function (suggestionElement)
{
  for (var i = 0; i < this.suggestionsBox.childNodes.length; i++)
  {
    var oElement = this.suggestionsBox.childNodes[i];
    if (oElement == suggestionElement)
    {
      oElement.className = "current";
    }
    else if (oElement.className == "current")
         {
           oElement.className = "";
         }
  }
}

AutoSuggestControl.prototype.createSuggestionsBox = function ()
{
  this.suggestionsBox = document.createElement("div")
  this.suggestionsBox.className = "suggestions";
  this.suggestionsBox.style.visibility = "hidden";
  this.suggestionsBox.style.width = this.textbox.offsetWidth;
  document.body.appendChild(this.suggestionsBox);
  
  var me = this;

  this.suggestionsBox.onmouseover = function (e)
  {
    var oEvent = e || window.event;
    var oSuggestion = oEvent.target || oEvent.srcElement;
    me.highlightSuggestion(oSuggestion);
  }

    this.suggestionsBox.onmousedown = function (e)
  {
    var oEvent = e || window.event;
    var oSuggestion = oEvent.target || oEvent.srcElement;
    me.textbox.value = oSuggestion.firstChild.nodeValue;
    me.hideSuggestionsBox();
  }

  this.suggestionsBox.onmouseup = function ()
  {
    me.textbox.focus();
  }
}

AutoSuggestControl.prototype.getLeft = function ()
{
  var oElement = this.textbox;
  var iLeft = 0;

  while (oElement.tagName != "BODY")
  {
    iLeft += oElement.offsetLeft;
    oElement = oElement.offsetParent;
  }
  return iLeft;
}

AutoSuggestControl.prototype.getTop = function ()
{
  var oElement = this.textbox;
  var iTop = 0;

  while (oElement.tagName != "BODY")
  {
    iTop += oElement.offsetTop;
    oElement = oElement.offsetParent;
  }
  return iTop + this.textbox.offsetHeight;
}

AutoSuggestControl.prototype.showSuggestions = function (suggestions)
{
  this.suggestionsBox.innerHTML = "";
  for (var i = 0; i < suggestions.length; i++)
  {
    var oDiv = document.createElement("div");
    oDiv.appendChild(document.createTextNode(suggestions[i]));
    this.suggestionsBox.appendChild(oDiv);
  }
  this.suggestionsBox.style.left = (this.getLeft() + "px");
  this.suggestionsBox.style.top = (this.getTop() + "px");
  this.suggestionsBox.style.visibility = "visible";
}

AutoSuggestControl.prototype.goToSuggestion = function (offset)
{
  var colSuggestionNodes = this.suggestionsBox.childNodes;
  if (colSuggestionNodes.length > 0)
  {
    var oNode = null;
    if (offset > 0)
    {
      if (this.currentSuggestionIndex < colSuggestionNodes.length - 1)
      {
        oNode = colSuggestionNodes[++this.currentSuggestionIndex];
      }
    }
    else if (this.currentSuggestionIndex > 0)
         {
            oNode = colSuggestionNodes[--this.currentSuggestionIndex];
         }
    if (oNode)
    {
      this.highlightSuggestion(oNode);
      this.textbox.value = oNode.firstChild.nodeValue;
    }
  }
}

AutoSuggestControl.prototype.handleKeyDown = function (e)
{
  switch (e.keyCode)
  {
    case 38: //up arrow
      this.goToSuggestion(-1);
    break;
    case 40: //down arrow
      this.goToSuggestion(1);
    break;
    case 27: //escape key
      this.textbox.value = this.actualText;
      this.selectTextRange(this.actualText.length, 0);
    case 13: //enter key
      this.hideSuggestionsBox();
      e.returnValue = false;
      if (e.preventDefault) e.preventDefault();
    break;
  }
}

