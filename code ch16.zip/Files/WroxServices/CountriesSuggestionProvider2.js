﻿  function SuggestionProvider(serviceUrl)
  {
    this.httpRequest = zXmlHttp.createRequest();
    this.serviceUrl = serviceUrl;
  }

  SuggestionProvider.prototype.fetchSuggestions = function (autoSuggestControl, show)
  {
    var request = this.httpRequest;
    if (request.readyState != 0)
    {
      request.abort();
    }
    var sQueryString = "?countryText=" + encodeURIComponent(autoSuggestControl.actualText);
    var sUrl = this.serviceUrl + sQueryString;
    request.onreadystatechange = function ()
    {
      if (request.readyState == 4)
      {
        var sData = request.responseText;
        var arrCountries = eval((sData));
        autoSuggestControl.suggest(arrCountries, show);
      }
    }
    request.open("GET", sUrl, true);
    request.send(null);
  }