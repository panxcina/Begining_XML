using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Xml;
using System.Xml.Xsl;
using System.Web.Caching;

public partial class _Default : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {
    XmlDocument countriesXml = new XmlDocument();
    if (Cache["countriesXml"] == null)
    {
      string xmlPath = Server.MapPath("countries.xml");
      countriesXml.Load(xmlPath);
      Cache.Insert("countriesXml", countriesXml, new CacheDependency(xmlPath));
    }
    else
    {
      countriesXml = (XmlDocument)Cache["countriesXml"];
    }
    XslCompiledTransform countriesXslt = new XslCompiledTransform();
    if (Cache["countriesXslt"] == null)
    {
      string xsltPath = Server.MapPath("countries.xslt");
      countriesXslt.Load(xsltPath);
      Cache.Insert("countriesXslt", countriesXslt, new CacheDependency(xsltPath));
    }
    else
    {
      countriesXslt = (XslCompiledTransform)Cache["countriesXslt"];
    }
    try
    {
      string countryText = Request.QueryString["countryText"];
      XsltArgumentList args = new XsltArgumentList();
      args.AddParam("countryText", "", countryText);
      countriesXslt.Transform(countriesXml, args, Response.OutputStream);
    }
    catch (Exception ex)
    {
      SendErrorXml(ex);
    }
  }

  private void SendErrorXml(Exception ex)
  {
    string errorXml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:wrox=\"http://www.wrox.com/webservices/GetCountries\"><soap:Body><wrox:GetCountriesResponse><wrox:countries/></wrox:GetCountriesResponse></soap:Body></soap:Envelope>";
    XmlDocument errorDoc = new XmlDocument();
    errorDoc.LoadXml(errorXml);
    errorDoc.Save(Response.OutputStream);
  }

}
