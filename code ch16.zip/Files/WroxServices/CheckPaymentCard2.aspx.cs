using System;

public partial class CheckPaymentCard : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {
    string cardNumber = Request.QueryString["cn"];
    if (string.IsNullOrEmpty(cardNumber))
    {
      SendResponse(false);
    }
    SendResponse(PerformLuhnCheck(cardNumber));
  }

  private bool PerformLuhnCheck(string cardNumber)
  {
    int sum = 0;
    try
    {
      for (int i = cardNumber.Length - 1; i >= 0; i--)
      {
        int currentDigit = int.Parse(cardNumber[i].ToString());
        if (i % 2 == 0)
        {
          currentDigit *= 2;
          if (currentDigit > 9)
          {
            currentDigit -= 9;
          }
        }
        sum += currentDigit;
      }
      return sum % 10 == 0;
    }
    catch (Exception)
    {
      return false;
    }
  }

  private void SendResponse(bool succeeded)
  {
    string xml = "<boolean>{0}</boolean>";
    Response.Write(string.Format(xml, succeeded));
    Response.End();
  }
}
